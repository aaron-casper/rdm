this is a very early version
it's a Remote Device Manager

the agent launches at login and reports various information back
to the server, running various services, including the master

the master is another tarball.

this tarball contains a bunch of scripts in ./AutoDiag that
perform various diagnostic and administrative tasks when called
from the master service on the server or an administrator

it also contains a python irc bot that performs this end of the
communication and triggered tasks

the code is rough

it is open source


use it
modify it
whatever

enjoy,
Aaron Casper

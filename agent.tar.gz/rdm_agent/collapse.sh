killall -u wfh ssh

sudo pkill -u rdm_agent ssh

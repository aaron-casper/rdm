ssh localhost -p 7000 -l pi
